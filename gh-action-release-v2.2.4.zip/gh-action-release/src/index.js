import hello from "./hello/index.js";

hello();
